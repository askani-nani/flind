
  var audio = new Audio('1.mp3');
  audio.play();
if (annyang) {
  // Let's define a command.

  const commands = {
    'cloths': () => { location.href = 'clothing.html'; }

 };
 
 const commands2 = {
    'footwear': () => { location.href = 'footwear.html'; }

 };
  

 


  // Add our commands to annyang
  annyang.addCommands(commands);
  annyang.addCommands(commands2);
 
  // Start listening.
  annyang.start();
}
