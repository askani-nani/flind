var sounds = new Array(new Audio("saree.mp3"), new Audio("CONFORM.mp3"));
var i = -1;
playSnd();

function playSnd() {
    i++;
    if (i == sounds.length) return;
    sounds[i].addEventListener('ended', playSnd);
    sounds[i].play();
}


if (annyang) {
    // Let's define a command.
   
    const commands = {
      'yes': () => { location.href = 'thankyou.html'; }
  
   };
   
   const commands2 = {
      'no': () => { location.href = 'index1.html';}
  
   };

     
  
  
  
    // Add our commands to annyang
    annyang.addCommands(commands);
    annyang.addCommands(commands2);
    
    // Start listening.
    annyang.start();
  }
