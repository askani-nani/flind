var audio = new Audio('buy menshirt.mp3');
audio.play(); 
if (annyang) {
  // Let's define a command.
 
  const commands = {
    'one': () => { location.href = 'mensshirt.html'; }

 };
 
 const commands2 = {
    'two': () => { location.href = 'menstshirt.html'; }

 };
  

 


  // Add our commands to annyang
  annyang.addCommands(commands);
  annyang.addCommands(commands2);
 
  // Start listening.
  annyang.start();
}
