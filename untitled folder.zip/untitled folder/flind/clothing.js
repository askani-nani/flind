
  var audio = new Audio('2.mp3');
  audio.play();
if (annyang) {
  // Let's define a command.

  const commands = {
    'menswear': () => { location.href = 'mens.html'; }

 };
 
 const commands2 = {
    'womenswear': () => { location.href = 'womens.html'; }

 };
  

 


  // Add our commands to annyang
  annyang.addCommands(commands);
  annyang.addCommands(commands2);
 
  // Start listening.
  annyang.start();
}
