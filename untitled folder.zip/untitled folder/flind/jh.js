var audio = new Audio('jacket buy.mp3');
audio.play(); 
if (annyang) {
  // Let's define a command.
 
  const commands = {
    'one': () => { location.href = 'mensjacket.html'; }

 };
 
 const commands2 = {
    'two': () => { location.href = 'menshoodie.html'; }

 };
  

 


  // Add our commands to annyang
  annyang.addCommands(commands);
  annyang.addCommands(commands2);
 
  // Start listening.
  annyang.start();
}
