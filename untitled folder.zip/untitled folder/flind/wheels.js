var sounds = new Array(new Audio("women black heels.mp3"), new Audio("size shoe.mp3"));
var i = -1;
playSnd();

function playSnd() {
    i++;
    if (i == sounds.length) return;
    sounds[i].addEventListener('ended', playSnd);
    sounds[i].play();
}

if (annyang) {
  // Let's define a command.
 
  const commands = {
    'seven': () => { var audio = new Audio('CONFORM.mp3');
    audio.play();  }

 };
 
 const commands2 = {
    'eight': () => { var audio = new Audio('CONFORM.mp3');
    audio.play(); }

 };
 const commands3 = {
    'nine': () => { var audio = new Audio('CONFORM.mp3');
    audio.play();  }
};
   



  // Add our commands to annyang
  annyang.addCommands(commands);
  annyang.addCommands(commands2);
  annyang.addCommands(commands3);
  // Start listening.
  annyang.start();
}
if (annyang) {
    // Let's define a command.
   
    const commands = {
      'yes': () => { location.href = 'thankyou.html'; }
  
   };
   
   const commands2 = {
      'no': () => { location.href = 'index1.html';}
  
   };

     
  
  
  
    // Add our commands to annyang
    annyang.addCommands(commands);
    annyang.addCommands(commands2);
    
    // Start listening.
    annyang.start();
  }
