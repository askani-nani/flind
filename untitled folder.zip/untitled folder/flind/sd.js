var audio = new Audio('sd.mp3.mp3');
audio.play(); 
if (annyang) {
  // Let's define a command.
 
  const commands = {
    'one': () => { location.href = 'womensaree.html'; }

 };
 
 const commands2 = {
    'two': () => { location.href = 'womendress.html'; }

 };
  

 


  // Add our commands to annyang
  annyang.addCommands(commands);
  annyang.addCommands(commands2);
 
  // Start listening.
  annyang.start();
}
