var audio = new Audio('login.mp3');
audio.play(); 
if (annyang) {
  // Let's define a command.
 
  const commands = {
    'kusuma': () => {  var audio = new Audio('password.mp3');
    audio.play(); }

 };
 
 const commands2 = {
    'one two three four': () => { location.href = 'index1.html'; }

 };
  

 


  // Add our commands to annyang
  annyang.addCommands(commands);
  annyang.addCommands(commands2);
 
  // Start listening.
  annyang.start();
}
if (annyang) {
    // Let's define a command.
   
    const commands = {
      'nani': () => {  var audio = new Audio('password.mp3');
      audio.play(); }
  
   };
   
   const commands2 = {
      'nani d n k': () => { location.href = 'index1.html'; }
  
   };
    
  
   
  
  
    // Add our commands to annyang
    annyang.addCommands(commands);
    annyang.addCommands(commands2);
   
    // Start listening.
    annyang.start();
  }
  if (annyang) {
    // Let's define a command.
   
    const commands = {
      'tarun': () => {  var audio = new Audio('password.mp3');
      audio.play(); }
  
   };
   
   const commands2 = {
      'sathya': () => { location.href = 'index1.html'; }
  
   };
    
  
   
  
  
    // Add our commands to annyang
    annyang.addCommands(commands);
    annyang.addCommands(commands2);
   
    // Start listening.
    annyang.start();
  }
  if (annyang) {
    // Let's define a command.
   
    const commands = {
      'mad': () => {  var audio = new Audio('password.mp3');
      audio.play(); }
  
   };
   
   const commands2 = {
      'i am mad': () => { location.href = 'index1.html'; }
  
   };
    
  
   
  
  
    // Add our commands to annyang
    annyang.addCommands(commands);
    annyang.addCommands(commands2);
   
    // Start listening.
    annyang.start();
  }
  if (annyang) {
    // Let's define a command.
   
    const commands = {
      'ram': () => {  var audio = new Audio('password.mp3');
      audio.play(); }
  
   };
   
   const commands2 = {
      'sita': () => { location.href = 'index1.html'; }
  
   };
    
  
   
  
  
    // Add our commands to annyang
    annyang.addCommands(commands);
    annyang.addCommands(commands2);
   
    // Start listening.
    annyang.start();
  }