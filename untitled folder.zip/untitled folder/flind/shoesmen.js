var audio = new Audio('men shoe buy.mp3');
audio.play(); 
if (annyang) {
  // Let's define a command.
 
  const commands = {
    'one': () => { location.href = 'mshoes.html'; }

 };
 
 const commands2 = {
    'two': () => { location.href = 'mflip.html'; }

 };
 const commands3 = {
    'three': () => { location.href = 'msandals.html'; }

 };
  

 


  // Add our commands to annyang
  annyang.addCommands(commands);
  annyang.addCommands(commands2);
  annyang.addCommands(commands3);
  // Start listening.
  annyang.start();
}
